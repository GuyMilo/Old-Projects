clear
clc

% Exact value of y(1)
y_exact = 2.604215099096980;

% Initial settings
initial_h = 0.1;
t_rng = [0, 1];
y0 = 1;

% Initial tolerance and array to store results
initial_eps_abs = 0.0001;
num_levels = 7; % For k = 0 to 6
tolerances = initial_eps_abs ./ (16 .^ (0:num_levels-1)); % Array of tolerances

% Initialize storage for results
steps = zeros(1, num_levels);
errors = zeros(1, num_levels);

% Run dp45 for each tolerance
for k = 1:num_levels
    % Set the current tolerance
    eps_abs = tolerances(k);
    
    % Run dp45 with the current tolerance
    [t_out, y_out] = dp45(@f4c, t_rng, y0, initial_h, eps_abs);
    
    % Store the number of steps and absolute error
    steps(k) = length(t_out);
    errors(k) = abs(y_out(end) - y_exact);
    
    fprintf('k = %d, epsilon = %.15f, steps = %d, error = %.15e\n', k-1, eps_abs, steps(k), errors(k));
end

% Display results
fprintf('\nTable 4.8f:\n');
fprintf(' k    epsilon_abs         steps     Absolute Error\n');
for k = 1:num_levels
    fprintf('%d    %.15f    %d        %.15e\n', k-1, tolerances(k), steps(k), errors(k));
end


function [dy] = f4c(t, y)
    dy = (4-t)/(y+t);
end

%jemgray
%James-Edward Gray
%21015159