clear
clc

[t4b, y4b] = dp45( @f4b, [0, 1], 0, 0.01, 1e-5 );
plot( t4b, y4b, 'or' )
[t4b, y4b] = ode45( @f4b, [0, 1], 0 );
hold on
plot( t4b, y4b, 'b' )
title( 'jemgray' )


function dy = f4b(t,y)  
dy = -t*y+y+t-cos(y);
end

%James-Edward Gray
%21015159
%jemgray