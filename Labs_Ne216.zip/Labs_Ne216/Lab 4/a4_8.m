clear
clc

%f4b = @(t,y) -t*y+y+t-cos(y);

[t2b, y2b] = rk4( @f4b, [0, 1], 0, 11 );
plot( t2b, y2b, 'or' )
[t4b, y4b] = ode45( @f4b, [0, 1], 0 );
hold on
plot( t4b, y4b, 'b' )
title( 'jemgray' )

%James-Edward Gray
%21015159

function dy = f4b(t,y)  
dy = -t*y+y+t-cos(y);
end