clear
clc

[t_vals, y_vals] = rk4( @f4c, [0, 1], 1, 11 );

disp('t values:');
disp(t_vals);
disp('y values:');
disp(y_vals);


function [dy] = f4c(t, y)
    dy = (4-t)/(y+t);
end

%James-Edward Gray
%21015159