function [t_out, y_out] = rk4(f, t_rng, y0, n)
    % The 4th-order Runge-Kutta method is a fixed-step method
    % for approximating the solution of an ODE.
    %
    % Parameters:
    % f: The function handle representing the ODE, dy/dt = f(t, y)
    % t_rng: A vector specifying the time range, [t0, tf]
    % y0: Initial value of y at t = t0
    % n: The number of steps for the fixed step size

    % Calculate the step size, h
    t0 = t_rng(1);
    tf = t_rng(2);
    h = (tf - t0) / n;

    % Initialize y_out and t_out
    t_out = linspace(t0, tf, n+1);
    y_out = zeros(length(y0), n+1);  % Corrected dimension of y_out
    y_out(:,1) = y0;

    % Main loop for each time step
    for k = 1:n
        t = t_out(k);
        y = y_out(:,k);

        % Calculate the four intermediate slopes
        K1 = h * f(t, y);
        K2 = h * f(t + h/2, y + K1/2);
        K3 = h * f(t + h/2, y + K2/2);
        K4 = h * f(t + h, y + K3);

        % Update y for each iteration
        y_out(:,k+1) = y + (K1 + 2*K2 + 2*K3 + K4) / 6;
    end
end

%jemgray
%James-Edward Gray
%21015159