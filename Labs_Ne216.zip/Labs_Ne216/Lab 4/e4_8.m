clear
clc

% Define parameters
initial_t = 0;
final_t = 1;
y0 = 1;
initial_h = 0.1;
eps_abs = 1e-6;

% Run the dp45 function with the specified parameters
[t_vals, y_vals] = dp45(@f4c, [initial_t, final_t], y0, initial_h, eps_abs);

% Select 11 evenly spaced points from t_vals and y_vals
num_points = 11;
selected_indices = round(linspace(1, length(t_vals), num_points));
t_selected = t_vals(selected_indices);
y_selected = y_vals(selected_indices);

% Display the results
disp('Selected t values:');
disp(t_selected);
disp('Selected y values:');
disp(y_selected);

function [dy] = f4c(t, y)
    dy = (4-t)/(y+t);
end

%James-Edward Gray
%21015159
%jemgray