clear
clf
clc
format long


% Define the 100 points btwn 0 and 5
x = linspace(0,5,100);  % 100 points from 0 to 5

% Initialize array to store Richardson extrapolation results
richardpts = zeros(1,length(x)); 

% Loop over each point in pts
for n = 1:length(x)
    richardpts(1,n) = richardson22(@Dc, @f2b, x(n),0.1, 5,1e-5);
end

hold on
% Title with UW user ID
title("jemgray")
% Plot the f2b(x) as a black line
plot(x,f2b(x),"k-",'LineWidth',1.5)
%v Plot the analytical derivative df2b(x) as a blue dashed line
plot(x,df2b(x),"b-",'LineWidth',1.5)
% Plot the numerical derivative from Richardson extrapolation as a red line
plot(x, richardpts,"r-.",'LineWidth',1.5);
% Legend with all the lines named
legend('f2b(x)', 'Analytical Derivative', 'Richardson Extrapolation');
hold off

% The function of f2b(x)
function [y] = f2b(x)
    y = 4*x.*exp(-2*x)-4*x.^(2).*exp(-x)+exp(-(1/2)*x);
end

% The analytical derivative df2b for f2b(x)
function [y] = df2b(x)
    y = 4.*exp(-2*x) - 8*x.*exp(-2*x) - 8*x.*exp(-x) + 4*x.^(2).*exp(-x) - (1/2)*exp(-(1/2)*x);
end

% Central difference approximation function
function result = Dc(u, x, h)
    result = (u(x + h) - u(x - h)) / (2 * h);  % Central difference approximation
end