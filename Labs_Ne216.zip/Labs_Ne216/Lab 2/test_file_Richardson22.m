clear
clc
format long

x1 = 3.26;
x2 = 6.06;

try
    result1 = richardson22( @D2c, @cos, x1, 0.1, 5, 1e-8 );
    disp(['Result for x1: ', num2str(result1)]);
catch ME
    disp(['Error for x1: ', ME.message]);
end

disp(['Expected result for x1: ', num2str(-cos( x1 ))]);

try
    result2 = richardson22( @D2c, @cos, x2, 0.1, 5, 1e-8 );
    disp(['Result for x2: ', num2str(result2)]);
catch ME
    disp(['Error for x2: ', ME.message]);
end

disp(['Expected result for x2: ', num2str(-cos( x2 ))]);

%Define Dc function for central difference
function result = Dc(u, x, h)
    result = (u(x + h) - u(x - h)) / (2 * h);  % Central difference approximation
end

%Define D2c function for the central difference for the second derivative
function result = D2c(u, x, h)
    % Central difference approximation for the second derivative of u at x
    result = (u(x + h) - 2 * u(x) + u(x - h)) / (h^2);
end