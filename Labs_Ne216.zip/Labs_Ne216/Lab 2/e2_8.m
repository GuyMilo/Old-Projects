clear
clc
format long
xvals = [1,2,4,8,16,32,5];

xevals = zeros(1, length(xvals));

for w = 1:length(xvals)
    try
    xevals(1,w) = richardson22(@Dc, @f2e, xvals(w), 0.1, 10, 1e-10);
    catch ME
    disp(['Error at x = ', num2str(xvals(w))]);
    xevals(1,w) = NaN;  % Set to NaN if it fails
    end
end

% Calculate the actual derivative
actdiff = df2e(xvals);

% Calculate absolute and relative errors
abs_error = zeros(1,length(xevals));
rel_error = zeros(1,length(xevals));
for w = 1:length(xvals)
    if ~isnan(xevals(1,w))
        abs_error(w) = abs(actdiff(w) - xevals(w));  % Absolute error
        rel_error(w) = abs_error(w) / abs(actdiff(w));  % Relative error
    else
        abs_error(w) = NaN;
        rel_error(w) = NaN;
    end
end

% Display the results
disp('xvals:');
disp(xvals);
disp('Approximations:');
disp(xevals);
disp('Actual Derivatives:');
disp(actdiff);
disp('Absolute Errors:');
disp(abs_error);
disp('Relative Errors:');
disp(rel_error);

function [y] = f2e(x)
    y = cos(x.^(2));
end

function [y] = df2e(x)
    y = -2.*x.*sin(x.^(2));
end

% Central difference approximation function
function result = Dc(u, x, h)
    result = (u(x + h) - u(x - h)) / (2 * h);  % Central difference approximation
end

%James-Edward Gray
%21015159