clear
clc


%richardson21( @Db, @sin, 1, 0.1, 5, 1e-5 )
%richardson21( @Db, @cos, 2, 0.1, 5, 1e-5 )
%richardson21( @Db, @cos, 2, 0.1, 5, 1e-10 )

BackwardsRichardson = richardson21( @Db, @f2c, 3*pi/2, 0.01, 5, 1e-10);
CentredRichardson = richardson22( @Dc, @f2c, 3*pi/2, 0.01, 5, 1e-10);

disp(['Result for Richardson extrapolation (for the backward divided-difference): ', num2str(BackwardsRichardson)]);
disp(['Result for Richardson extrapolation (for the centred divided-difference): ', num2str(CentredRichardson)])

% Backward difference approximation function
function result = Db(u, x, h)
    result = (u(x) - u(x - h)) / h;  % Backward difference approximation
end

function [y] = f2c(x)
    y = abs( cos(x) );
end

% Central difference approximation function
function result = Dc(u, x, h)
    result = (u(x + h) - u(x - h)) / (2 * h);  % Central difference approximation
end

%James-Edward Gray 
%21015159