function [du] = richardson22( D, u, x, h, N_max, eps_abs )
% richardson22
% The Richardson extrapolation uses the information from coarser approximations 
% to correct and refine the final result, allowing you to achieve more significant 
% digits of accuracy without needing an impractically small step size.
%
% Parameters
% ==========
%    D A function that calculates the numerical derivative of u at x, using the step size h.
%    u A function handle representing the function whose derivative you want to approximate
%
%    x The point at which the derivative is approximated
%    h The small step size, in this case 22, used for the difference approximation
%
%    N_max   The maximum number of iterations for the Richardson extrapolation
%    eps_abs The absolute error tolerance used as a convergence criterion for the 
%	      Richardson extrapolation.
%
% Return Value
% ============
%    du the refined derivative approximation after the matrix-based Richardson extrapolation function has been called.

if ~isa(D, 'function_handle') || ~isa(u, 'function_handle')
        throw( MException( 'MATLAB:invalid_argument', ...
        'Either your D or u arguements are not function handles' ) );
elseif ~isscalar(x) || ~isscalar(h) || ~isscalar(N_max) || ~isscalar(eps_abs)
        throw( MException( 'MATLAB:invalid_argument', ...
        'Sorry, but one of your scalar arguements, either x,h,N_Max or eps_abs, are not scalar') );
elseif N_max ~= round(N_max) || eps_abs <= 0
         throw( MException( 'MATLAB:invalid_argument', ...
        'Error, your N_max (max iterations) must be a integer, and/or check that your eps_abs (absolute error tolerance) is a positive scalar (meaning it should be > 0 :)') );

end

%initialize the Richardson Extrapolation matrix
R = zeros(N_max+1, N_max +1);

% Compute the initial approximation

R(1,1) = D(u,x,h);

%Setting up the for loop
for i = 1:N_max
    %Halve the step size for each iteration
    R(i+1,1)= D(u,x,h/2^(i));

    %Nested loop for refining values using the Richard Extrapolation
    for j = 1:i
        %Applying the Richardson Extrapolation formula
        R(i+1,j+1)= (4^(j).*R(i+1,j)- R(i,j))./(4^(j) - 1);
    end

    %Check for convergence
    if abs(R(i+1, j+1) - R(i,j)) < eps_abs
       du = R(i+1,j+1); %this sets the refined derivative approximation
       return; 
    end

end
%Handle non-convergence if the loop finishes without convergence
error('Richardson extrapolation did not converge within the allowed iterations.');
end
%James-Edward Gray
%21015159