clear
clc
format long

%Define x values
x1 = 1;
x2 = 2;
x3 = 3;
x4 = 4;

%Call richardson22 fctn for each result and compare it to the derivative
try
result1 = richardson22( @Dc, @f2a, x1, 0.1, 5, 1e-5);
disp(['Result for x1: ', num2str(result1)]);
catch ME
    disp(['Error for x1: ', ME.message]);
end
disp(['Expected result for x1: ', num2str(df2a(x1))]);

try
result2 = richardson22( @Dc, @f2a, x2, 0.1, 5, 1e-5);
disp(['Result for x2: ', num2str(result2)]);
catch ME
    disp(['Error for x2: ', ME.message]);
end
disp(['Expected result for x2: ', num2str(df2a(x2))]);

try
result3 = richardson22( @Dc, @f2a, x3, 0.1, 5, 1e-5);
disp(['Result for x3: ', num2str(result3)]);
catch ME
    disp(['Error for x3: ', ME.message]);
end
disp(['Expected result for x3: ', num2str(df2a(x3))]);

try
result4 = richardson22( @Dc, @f2a, x4, 0.1, 5, 1e-5);
disp(['Result for x4: ', num2str(result4)]);
catch ME
    disp(['Error for x4: ', ME.message]);
end
disp(['Expected result for x4: ', num2str(df2a(x4))]);

% Function f2a for f(x)
function [y] = f2a(x)
    y = x.^2.*exp(-x);
end

% Analytical derivative df2a for f'(x)
function [y] = df2a(x)
    y = 2*x.*exp(-x)-x.^(2).*exp(-x);
end

% Central difference approximation function
function result = Dc(u, x, h)
    result = (u(x + h) - u(x - h)) / (2 * h);  % Central difference approximation
end