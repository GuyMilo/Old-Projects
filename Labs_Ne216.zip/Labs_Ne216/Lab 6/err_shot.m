function du_b = err_shot(s, f, x_rng, u_bndry, h, eps_abs)
% err_shot
% computes the error for a given slop, x, in the shooting method.
% it solves the ODE with the provided slope and calculates the 
% difference between the computed and target boundary values at 
% the right end point.

% Step 1: Extract the boundary conditions
u_a = u_bndry(1); % Value of the soln at the left entry (i.e. x_rng(1)
u_b = u_bndry(2); % The target value of the solution at the right 
                  % boundary (i.e. x_rng(2))

% Step 2: Solve the ODE using dp45                 
[~,u_out] = dp45(f, x_rng, [u_a, s]', h, eps_abs);

% Step 3: Compute the error
% where the error is the difference between the computer and target right 
% boundary values.
du_b = u_out(1,end) - u_b;
end

% James-Edward Gray 
% 21015159