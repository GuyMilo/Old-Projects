function dw = f6a(x,w)

% f6a: Defines the inhomogeneous ODE for the given boundary value problem
% 
% from the the eqn from the slides:
% u''(x) + sin(x)u'(x) + u(x) = 1
%
% Let:
% Inhomogeneous
% w(1) = u(x) (the solution) 
% w(2) = u'(x) (the derivative of the solution)
% Homogeneous
% w(3) = u(x) 
% w(4) = u'(x) (the derivative of the solution)
% 
% Output: dw, the derivatives [w1', w2']
%
% System of first-order ODEs:
% w1'(x) = w2(x)
% w2'(x) = 1 - sin(x)*w(2) - w(1)

% First initialize the derivative vector 
dw = zeros(4,1); % a column vector for [inhomogeneous; homogeneous]

% Next define the system of first-order ODEs
% Inhomogeneous system
dw(1) = w(2); % w1'(x) = w2(x)
dw(2) = 1 - sin(x)*w(2)-w(1); % w2'(x) = 1 - sin(x)*w(2) - w(1)
% Homogeneous system
dw(3) = w(4); % u'(x) for homogeneous
dw(4) = -sin(x)*w(4) - w(3); % u''(x) for homogeneous

end