clear
clc

[x6c, u6c] = shooting(-3, -3.1, @f6c, [2, 3], [1.5, 2.5]', 0.01, 1e-2, 1e-2, 20);
