clear
clc
% Define the problem parameters
x_rng = [0, 2 * pi]; % Range of x values
u_bndry = [2, 3];    % Boundary conditions u(0) = 2, u(2*pi) = 3
h = 0.1;             % Initial step size
eps_step = 1e-4;     % Step size tolerance
N_max = 100;         % Maximum iterations for the shooting method

% Define initial guesses for slopes
s1 = -1; % Arbitrary initial guess 1
s2 = 1;  % Arbitrary initial guess 2

% Solve the BVP for different epsilon_abs values
eps_abs_values = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5];
results = cell(length(eps_abs_values), 1); % Store solutions for each epsilon_abs

% Loop through epsilon_abs values
for i = 1:length(eps_abs_values)
    eps_abs = eps_abs_values(i); % Current absolute tolerance
    
    % Solve using the shooting method
    fprintf('Solving for eps_abs = %.1e\n', eps_abs);
    try
        [x_out, u_out] = shooting(s1, s2, @f6e, x_rng, u_bndry, h, eps_abs, eps_step, N_max);
        results{i} = struct('eps_abs', eps_abs, 'x', x_out, 'u', u_out);
    catch ME
        fprintf('Failed to solve for eps_abs = %.1e: %s\n', eps_abs, ME.message);
        results{i} = struct('eps_abs', eps_abs, 'x', [], 'u', []);
    end
end

% Plot results
figure;
hold on;
for i = 1:length(results)
    if ~isempty(results{i}.x)
        plot(results{i}.x, results{i}.u(1, :), 'DisplayName', sprintf('\\epsilon_{abs} = %.1e', results{i}.eps_abs));
    end
end
title('Solutions to the BVP for Different Values of \epsilon_{abs}');
xlabel('x');
ylabel('u(x)');
legend('show');
grid on;
hold off;

% James-Edward Gray
% 21015159