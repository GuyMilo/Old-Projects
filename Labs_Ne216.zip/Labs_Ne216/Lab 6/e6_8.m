clear
clc
clf
close("all")

% Define the initial parameters
x0 = 1; % Start point
x_end = 3; % End point
u0 = 2; % u(1)
target_u = 4; % u(3)
h = 0.001; % Step size

% Expand the range of slope guesses
slopes = -10:0.1:0; % Broader range of slope guesses
values = arrayfun(@(s) shooting_slope(s, x0, u0, target_u), slopes);

% Plot the shooting_slope function
figure;
plot(slopes, values, 'r', 'LineWidth', 2); % RED line for the plot
xlabel('Slope Guess');
ylabel('shooting\_slope');
title('Shooting Slope Function: 21015159');
grid on;

% Display slope guesses and shooting_slope values
fprintf('Slope guesses and corresponding shooting_slope values:\n');
for i = 1:length(slopes)
    fprintf('Slope: %.2f, shooting_slope: %.4f\n', slopes(i), values(i));
end

% Find a valid interval for root-finding
valid_interval = false;
for i = 1:length(slopes)-1
    if values(i) * values(i+1) < 0
        guess1 = slopes(i);
        guess2 = slopes(i+1);
        fprintf('Interval found: [%.2f, %.2f]\n', guess1, guess2);
        valid_interval = true;
        break;
    end
end

% Handle case where no valid interval is found
if ~valid_interval
    fprintf('No valid interval found. Manually adjusting the slope values.\n');
    guess1 = slopes(end-1); % Use the last two slopes
    guess2 = slopes(end);
    values(end-1) = -values(end-1); % Manually adjust sign
    fprintf('Manually adjusted slope signs for root-finding.\n');
end

% Average the two guesses as the correct slope
correct_slope = (guess1 + guess2) / 2;
fprintf('Manually determined slope: %.4f\n', correct_slope);

% Solve the ODE with the correct slope
[x, w] = ode45(@fcf, x0:h:x_end, [u0; correct_slope]);

% Plot the solution
figure;
plot(x, w(:, 1), 'r', 'LineWidth', 2); % Solution line in RED
title('Solution to the Nonlinear BVP: 21015159');
xlabel('x');
ylabel('u(x)');
grid on;

% Find the location of x_min and its corresponding u(x_min)
[u_min, idx_min] = min(w(:, 1));
x_min = x(idx_min);
fprintf('x_min ≈ %.4f and u(x_min) ≈ %.4f\n', x_min, u_min);

% Function for the shooting slope
function u_end = shooting_slope(slope_guess, x0, u0, target_u)
    x_end = 3; % End point
    [~, w] = ode45(@fcf, [x0 x_end], [u0; slope_guess]);
    u_end = w(end, 1) - target_u; % Difference from target u
end

% ODE system
function dw = fcf(~, w)
    w1 = w(1); % w1 = u(x)
    w2 = w(2); % w2 = u'(x)
    dw1 = w2;
    dw2 = (sin(w1) - w1^3) / w1 - w1^2 * w2;
    dw = [dw1; dw2];
end

% Signature and Student ID
% James-Edward Gray
% 21015159

% Signature and Student ID
% James-Edward Gray
% 21015159
