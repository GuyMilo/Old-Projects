function [t_out, y_out] = dp45(f, t_rng, y0, h, eps_abs)
% The Dormand-Prince method is an adaptive-step method, adjusting the step 
% size dynamically based on the estimated error. This method is designed 
% to work well with the shooting method by ensuring robust step size control.

% Parameters: 
% f: The function handle representing the ODE, dy/dt = f(t, y)
% t_rng: A vector specifying the time range, [t0, tf]
% y0: Initial value of y at t = t0
% h: Initial step size 
% eps_abs: Desired absolute error tolerance

% Define Dormand-Prince coefficient matrix A
A = [0 0 0 0 0 0 0; 
      1/5 0 0 0 0 0 0;
      3/40 9/40 0 0 0 0 0;
      44/45 -56/15 32/9 0 0 0 0;
      19372/6561 -25360/2187 64448/6561 -212/729 0 0 0;
      9017/3168 -355/33 46732/5247 49/176 -5103/18656 0 0;
      35/384 0 500/1113 125/192 -2187/6784 11/84 0];

% Define the Dormand-Prince step coefficient vector c
c = [0 1/5 3/10 4/5 8/9 1 1];

% Define the high-order (b_high) and low-order (b_low) weight vectors
b_high = [35/384 0 500/1113 125/192 -2187/6784 11/84 0];
b_low = [5179/57600 0 7571/16695 393/640 -92097/339200 187/2100 1/40];

% Initialize variables
t0 = t_rng(1);
tf = t_rng(2);
y = y0;
t_out = t0;
y_out = y;

% Minimum step size to avoid infinite loops
min_h = 1e-10;
max_h = 0.01;  % Maximum allowable step size to ensure sufficient resolution

while t_out(end) < tf
    if t_out(end) + h > tf
        h = tf - t_out(end); % Adjust final step to land exactly on tf
    end

    % Compute K values for the Dormand-Prince method using a loop
    K = zeros(length(y0), 7);
    for m = 1:7
        % Compute the weighted sum of previous Ks for the current stage
        y_temp = y_out(:, end) + K(:, 1:m-1) * A(m, 1:m-1)';
        K(:, m) = h * f(t_out(end) + c(m) * h, y_temp);
    end

    % High-order (5th) and low-order (4th) solutions
    y_high = y_out(:, end) + K * b_high';
    y_low = y_out(:, end) + K * b_low';

    % Error estimate and adaptive step size control
    error_estimate = norm(y_high - y_low, inf);
    if error_estimate > 0
        s = min(1.5, max(0.5, (eps_abs / (2 * error_estimate))^(1/4))); % Conservative scaling
    else
        s = 1.5; % If error estimate is zero, increase s conservatively
    end

    if s >= 1
        % Accept step
        t_out(end+1) = t_out(end) + h;
        y_out(:, end+1) = y_high;
        h = min(h * s, max_h); % Increase h but limit to max_h
    else
        % Reject step and reduce h
        h = max(h * s, min_h);
    end
end
end
% This version is optimized for use with the shooting method, providing stable adaptive step control.

% James-Edward Gray
% 21015159
