clear 
clc

[x6d, u6d] = shooting(-3, -3.1, @f6d, [-1, 1], [2, 3]', 0.01, 1e-4, 1e-4, 20);

% Plot the result
plot(x6d, u6d(1, :), 'r-', 'LineWidth', 2); % Red line for u(x)
title('Solution to the Linear BVP - UW User ID: 21015159');
xlabel('x');
ylabel('u(x)');
grid on;

% James-Edward Gray
% 21015159