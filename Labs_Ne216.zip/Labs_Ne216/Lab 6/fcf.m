function dw = fcf(x, w)
    % Input: x (independent variable), w (vector [w1; w2])
    % Output: dw (vector of derivatives [dw1; dw2])
    
    % Unpack variables
    w1 = w(1); % w1 = u(x)
    w2 = w(2); % w2 = u'(x)
    
    % Compute derivatives
    dw1 = w2;
    dw2 = (sin(x) - w1^3) / w1 - w1^2 * w2;
    
    % Return derivatives as a column vector
    dw = [dw1; dw2];
end

% James-Edward Gray
% 21015159