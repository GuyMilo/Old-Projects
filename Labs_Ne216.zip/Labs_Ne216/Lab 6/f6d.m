function [dw] = f6d(x, w)
    % f6d defines the system of first-order ODEs for the given BVP
    %
    % Parameters:
    % x  - Independent variable
    % w  - Vector containing [w1; w2] where:
    %      w1 = u(x), w2 = u'(x)
    %
    % Returns:
    % dw - Derivative vector [w1'; w2']

    % Initialize the output vector
    dw = zeros(2, 1);

    % Define the system of ODEs
    dw(1) = w(2); % w1' = w2
    dw(2) = exp(-x) - x^2 * w(2) - (1 - x^2) * w(1); % w2' = RHS of the ODE
end

% James-Edward Gray
% 21015159