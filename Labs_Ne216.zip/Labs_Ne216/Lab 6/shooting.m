function [x_out, u_out] = shooting(s1, s2, f, x_rng, u_bndry, h, eps_abs, eps_step, N_max)
% shooting
% 
% The shooting method solves boundary value problems (BVPs) by 
% transforming them into initial value problems (IVPs). It 
% guesses the initial slope at one boundary, integrates the ODE, 
% and iteratively adjusts the slope using methods like the secant 
% method until the solution satisfies the boundary conditions at 
% both ends. This approach is effective for both linear and nonlinear 
% ODEs.
%
% Parameters:
% s1        Initial slope guess 1; this is the first approximation of the slope at the left boundary.
% s2        Initial slope guess 2; this is the second approximation of the slope at the left boundary.
% f         The differential equation function handle; defines the ODE as u''(x) = f(x, u(x), u'(x)).
% x_rng     Row vector defining the range of x values [a, b] for the BVP.
% u_bndry   Row vector [u_a, u_b] specifying the boundary conditions at x = a and x = b.
% h         Initial step size for the numerical integration method (e.g., dp45).
% eps_abs   Absolute tolerance for the error in the solution at the right boundary.
% eps_step  Convergence criterion for the change in slope between iterations.
% N_max     Maximum number of iterations allowed for the secant method.
%
% Return Values:
% x_out     Row vector of x values corresponding to the solution over the interval.
% u_out     Matrix of solution values; columns correspond to components (e.g., u(x), u'(x)).

% Step 0: Initialize errors
err1 = err_shot(s1, f, x_rng, u_bndry, h, eps_abs);
err2 = err_shot(s2, f, x_rng, u_bndry, h, eps_abs);

% Convergence threshold for divergence checks
max_error_threshold = 1e2;

% Step 1: Iteration loop
for N = 1:N_max
    % Step 2: Check error magnitudes
    if abs(err1) > max_error_threshold || abs(err2) > max_error_threshold
        fprintf('Error magnitude exceeds threshold at iteration %d. Resetting range.\n', N);
        s1 = s1 - (s2 - s1) / 2;
        s2 = s2 + (s2 - s1) / 2;
        err1 = err_shot(s1, f, x_rng, u_bndry, h, eps_abs);
        err2 = err_shot(s2, f, x_rng, u_bndry, h, eps_abs);
        continue;
    end

    % Step 3: Calculate new slope using secant method
    if abs(err2 - err1) > 1e-12
        s = s2 - err2 * (s2 - s1) / (err2 - err1);
    else
        fprintf('Fallback to midpoint at iteration %d.\n', N);
        s = (s1 + s2) / 2;
    end

    % Step 4: Compute the new error
    err_new = err_shot(s, f, x_rng, u_bndry, h, eps_abs);

    % Step 5: Print debugging information
    fprintf('Iteration %d: s1 = %.4f, s2 = %.4f, s = %.4f, err_new = %.4e\n', N, s1, s2, s, err_new);

    % Step 6: Check for convergence
    if abs(err_new) < eps_abs && abs(s2 - s1) < eps_step
        [x_out, u_out] = dp45(f, x_rng, [u_bndry(1), s]', h, eps_abs);
        
        % Step 9: Downsample the output arrays to a smaller size
        num_points = min(100, length(x_out)); % Limit points to user's liking while retaining accuracy
        indices = round(linspace(1, length(x_out), num_points)); % Evenly spaced indices
        x_out = x_out(indices); % Resample x values
        u_out = u_out(:, indices); % Resample solution values
        
        fprintf('Converged after %d iterations.\n', N);
        return;
    end

    % Step 7: Adjust search range
    if err_new * err2 < 0
        s1 = s2;
        err1 = err2;
    end
    s2 = s;
    err2 = err_new;
end

% Step 8: Handle failure to converge
error('No root found within the maximum number of iterations!');
end

% James-Edward Gray
% 21015159