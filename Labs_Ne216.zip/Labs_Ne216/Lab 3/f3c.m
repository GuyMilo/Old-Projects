function [dy] = f3c(t,y)
    dy = (4-t)/(y+t);
end