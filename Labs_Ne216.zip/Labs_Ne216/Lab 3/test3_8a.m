clear
clc

[t3a, y3a] = euler( @f3a, [0, 1], 0, 11 ); 
plot( t3a, y3a, 'or' )
hold on
[t3a, y3a] = ode45( @f3a, [0, 1], 0 );
plot( t3a, y3a, 'b' )


function [y] = y3a_soln( t )
    y = (t.^3 - 3*t.^2 + 3*t)./(t.^3 - 3*t.^2 + 3*t + 3);
end

