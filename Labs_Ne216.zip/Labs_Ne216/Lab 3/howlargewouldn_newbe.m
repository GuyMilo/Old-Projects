clear
clc

n_new = ceil((0.001610763874782/0.001)*641)
%James-Edward Gray
%21015159
%jemgray