%1.6b
clear
clc

num = 10532.0947265625;

%Convert the number, num, to its IEE 754 binary representation.  MATLAB
%uses IEEE 754 format for storing floating-point numbers
binary_rep = typecast(num, 'uint64');
%Which gives us the 64-bit unsigned integer representation

%Next, convert the 64-bit unsigned integer to a 64-bit binary string
binary_string = dec2bin(binary_rep, 64);

%Now the first bit of the binary string is the sign bit, so we excract the
%first bit
sign_bit = binary_string (1)

%Next, the exponent bits are defined as the the following 11 bits (from
%position 2 to 12) which represent the exponent
exponent_bits = binary_string(2:12)

%Lastly, the mantissa bits are defined as the remaining 52 bits (from
%position 13 to 64), note that there are only 64 bits, so it's in reality, 
%the remainder digits efter the exponent(51).
mantissa_bits = binary_string(13:end)

%Now, note that the exponent in IEEE 754 format has a bias of 1023.  THe
%actual exponent is calculated by subtracting 1023 from the binary exponent
%value, so we will include that as well.
exponent_decimal = bin2dec(exponent_bits) - 1023

%James-Edward Gray
%21015159

