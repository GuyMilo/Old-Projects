function [x2] = secant(f, x0, x1, eps_step, eps_abs, N_Max)
% Secant method
%
% Write a description of what the function is suppose to do here.  It should be a
% paragraph or two.
%
% This function implements the secant method to find the root of a nonlinear
% equation f(x) = 0. The secant method is an iterative technique that approximates 
% the root by drawing a secant line between two initial guesses x0 and x1 and 
% solving for the point where the secant line crosses the x-axis. 
% 
%
% Parameters                
% ==========                 
%    f         Function handle for the equation f(x) = 0 whose root is being sought.
%              It must be passed as a handle using the @ symbol (e.g., @cos).
%
%    x0        First initial guess for the root of the function f(x). This is the 
%              starting point of the iteration.
%
%    x1        Second initial guess for the root of the function f(x). The secant 
%              method approximates the root based on these two initial guesses.
%
%    eps_step  The tolerance for the step size between successive approximations. 
%              The iteration stops when the difference between x1 and x2 is less 
%              than this value. This controls the precision of the root approximation.
%
%    eps_abs   The tolerance for the function value at the approximate root. 
%              If abs(f(x2)) is less than this value, the function assumes that 
%              x2 is close enough to the actual root and stops iterating.
%
%    N_max     Maximum number of iterations allowed. This prevents the function 
%              from running indefinitely if the method fails to converge. If this 
%              limit is reached, the function throws an error.
%
% Return Values              For each return value, indicate the significance.
% =============
%    x2        The approximate root of the equation f(x) = 0 found by the secant method.
%              It is the value where the function f(x) is close to zero based on
%              the specified tolerances eps_step and eps_abs.

    for i = 1:N_Max %the for loop is used to keep track of the iterations

        %The Classic Secant fctn, used to calculate the next approximation
        x2 = x1 - (f(x1)*(x1-x0))/(f(x1)-f(x0)); 
        % Check if the difference conditions are met; if so return the
        % value
        if abs(x2 - x1 ) < eps_step && abs(f(x2)) < eps_abs
            return;
        end
        % Update x0 and x1 for the next iteration
        x0 = x1;
        x1 = x2;
    end
    % If the method does not converge within N_max iterations, throw an error
    if i == N_Max
        throw( MException('MATLAB:numeric_exception','function doesn''t converge with the given N_Max, or there''s a possibility that the root just simply DNE.'))
    end
end
%James-Edward Gray
%21015159