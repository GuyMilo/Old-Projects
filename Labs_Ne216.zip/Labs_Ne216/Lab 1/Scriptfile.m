%1.1
%secant(@cos,1,1.1)
%secant(@log,4,2)

% 1.2
% ans1 = secant(@sin, 3, 3.1, 20)
% ans2 = secant(@f1a, 3, 3.1, 20)
% 
% function[y] = f1a( x )
%     y = x.^2 + 1;
% end

%1.3
%secant( @f1b, 0.000722, 0.0007221, 100 )
% secant( @f1b, 0.000722, 0.0007221, 1e-4, 100 )
% 
% function [y] = f1b( x )
%     y = cos(1./x);
% end

clear
clc
format long

x1b = secant( @f1b, 0.000722, 0.0007221, 1e-6, 1e-10, 100 )
f1b(x1b)
function [y] = f1b( x )
    y = cos(1./x);
end


%James-Edward Gray
%21015159