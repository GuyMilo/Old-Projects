clear
clc

% Define the hexadecimal representations
hex_values = {'3f293ac9d935310c', '1ce0f5ff5675cf94', 'd933f307fea5b029', ...
              'b5fe6a8a831e7905', '28a43e05659feaf3', '3744be1ee8f9f90c'};

% Loop through each hex value
for i = 1:length(hex_values)
    % Convert hex to double
    num = hex2num(hex_values{i});
    
    % Display whether the number is positive or negative
    if num >= 0
        disp(['Hex value ', hex_values{i}, ' is Positive']);
    else
        disp(['Hex value ', hex_values{i}, ' is Negative']);
    end
end

%James-Edward Gray
%21015159