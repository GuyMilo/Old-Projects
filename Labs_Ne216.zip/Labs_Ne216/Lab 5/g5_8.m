clear
clc

% Define constants
student_id = 21015159; % my student !D
x0 = 1 / student_id; % Initial condition for x(0)
dx0 = 0; % Initial condition for x'(0)

% Define the system of ODEs
f = @(t, y) [y(2); 
             5 * cos(4 * t) - 1.2 * y(2) - 2 * y(1)];

% Define the time range and initial conditions
t_rng = [0, 20];
y0 = [x0; dx0];
h = 0.01;
eps_abs = 1e-8;

% Solve using dp45
[t_out, y_out] = dp45(f, t_rng, y0, h, eps_abs);

% Plot the solution
figure;
plot(t_out, y_out(1, :), 'b', 'LineWidth', 1.5);
xlabel('Time (t)');
ylabel('Displacement (x(t))');
title(['Displacement vs Time for Student ID ', num2str(student_id)]);
grid on;

% Author and ID
disp('James-Edward Gray');
disp('21015159');