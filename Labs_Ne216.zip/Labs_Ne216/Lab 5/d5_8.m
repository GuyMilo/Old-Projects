clear
clc

% Adjusted parameters for testing
initial_h = 0.01; % Increased initial step size
tolerance = 1e-3; % Relaxed tolerance
time_range = [0, 2]; % Reduced time range for testing

% Solve the system using dp45
[t5b, y5b] = dp45(@f5b, time_range, [1; 1; 1], initial_h, tolerance);

% Check if the solver completed successfully
if isempty(t5b) || isempty(y5b)
    disp('Solver did not return any results.');
else
    % Plot the results if solver was successful
    figure;
    plot3(y5b(1, :), y5b(2, :), y5b(3, :), 'b', 'LineWidth', 1.5);
    xlabel('Variable 1');
    ylabel('Variable 2');
    zlabel('Variable 3');
    title('3D Trajectory of the System');
    grid on;

    figure;
    plot(t5b, y5b(1, :), 'r', 'DisplayName', 'Variable 1'); hold on;
    plot(t5b, y5b(2, :), 'g', 'DisplayName', 'Variable 2');
    plot(t5b, y5b(3, :), 'b', 'DisplayName', 'Variable 3');
    xlabel('Time');
    ylabel('Solution Values');
    title('Time-Series of the System Variables');
    legend;
    grid on;
end

% Author and ID
disp('James-Edward Gray');
disp('21015159');