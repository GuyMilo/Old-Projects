clear
clc

% Initial conditions
w0 = [1; 0.5; 0.2; 0.1];

% Time range and parameters
t_rng = [0, 40];
h = 0.01;
eps_abs = 1e-8;

% Solve the system using dp45
[t_out, w_out] = dp45(@f5f, t_rng, w0, h, eps_abs);

% Extract u(t) and v(t)
u = w_out(1, :);
v = w_out(3, :);

% Plot the results
figure;
plot(t_out, u, 'b', 'LineWidth', 1.5); hold on;
plot(t_out, v, 'r', 'LineWidth', 1.5);
xlabel('Time (t)');
ylabel('Displacement');
title(['Coupled Functions u(t) and v(t) for Student ID 21015159']);
legend('u(t)', 'v(t)', 'Location', 'best');
grid on;

% Author and ID
disp('James-Edward Gray');
disp('21015159');