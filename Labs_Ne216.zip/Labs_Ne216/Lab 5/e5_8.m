clear
clc
format long

% Solve the system
[t5c, y5c] = dp45(@f5c, [0, 1], [1.2, 1.3]', 0.1, 1e-4);

% Display results
disp('Time points (t5c):');
disp(t5c);
disp('Solution (y5c):');
disp(y5c);

% Author and ID
disp('James-Edward Gray');
disp('21015159');