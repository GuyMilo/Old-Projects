function dydt = f5c(t, y)
    % Example system of ODEs
    dydt = [y(2); 
            -y(1)];
end