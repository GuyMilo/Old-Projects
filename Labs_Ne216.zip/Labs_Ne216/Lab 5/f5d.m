function dydt = f5d(t, y)
    R = 1; % Resistance (Ohms)
    L = 1; % Inductance (Henries)
    C = 1; % Capacitance (Farads)
    
    % Input voltage as a function of time
    if t < 5
        Vin = 1;
    else
        Vin = 0;
    end
    
    % Define the system of equations
    dydt = [y(2);
            Vin/L - (R/L)*y(2) - (1/(L*C))*y(1)];
end