clear
clc

% Initial setup
tf = 6.6; % Start of the range
tolerance = 0.001;
norm_diff = inf;

% Iteratively refine tf
while norm_diff >= tolerance && tf <= 7.0
    [t5a, y5a] = dp45(@f5a, [0, tf], [3/10; 1/2], 0.001, 1e-10);
    norm_diff = norm(y5a(:, end) - y5a(:, 1));
    disp(['tf = ', num2str(tf), ', norm difference = ', num2str(norm_diff)]);
    
    % Check for convergence
    if norm_diff < tolerance
        disp(['Converged! tf = ', num2str(tf), ', norm difference = ', num2str(norm_diff)]);
        % Plot the phase portrait
        plot(y5a(1, :), y5a(2, :), 'b', 'LineWidth', 1.5);
        xlabel('Prey Population');
        ylabel('Predator Population');
        title(['Predator-Prey Dynamics, Period = ', num2str(tf)]);
        grid on;
        legend('Predator-Prey Trajectory', 'Location', 'Best');
        break;
    end
    
    % Increment tf
    tf = tf + 0.001; % Smaller increment for refinement
end

% If the loop finishes without convergence
if norm_diff >= tolerance
    disp('Failed to converge within the specified range.');
end

% Author and ID
disp('James-Edward Gray');
disp('21015159');