function dy = f5a(t, y)
    % Predator-prey model
    dy = [y(1) - y(1) * y(2);  
          -y(2) + y(1) * y(2)]; 
end