clear
clc

% Solve the RLC circuit system
[t5d, y5d] = dp45(@f5d, [0, 10], [0; 0], 0.1, 1e-8);

% Plot charge and current
figure;
plot(t5d, y5d(1, :), 'r', 'DisplayName', 'Charge (q)');
hold on;
plot(t5d, y5d(2, :), 'b', 'DisplayName', 'Current (i)');
xlabel('Time (s)');
ylabel('Amplitude');
title('Charge and Current in the RLC Circuit: jemgray');
legend('Location', 'best');
grid on;

% Author and ID
disp('James-Edward Gray');
disp('21015159');