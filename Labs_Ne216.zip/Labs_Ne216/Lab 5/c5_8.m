clear
clc

% Set display format for precision
format long

% Solve the system using dp45
[t5b, y5b] = dp45(@f5b, [0, 0.4], [1; 1; 1], 0.1, 1e-1);

% Display the output
disp('Time Points (t5b):');
disp(t5b);

disp('Solution (y5b):');
disp(y5b);

% Plot the results
figure;
plot(t5b, y5b(1, :), 'r', 'DisplayName', 'Variable 1'); hold on;
plot(t5b, y5b(2, :), 'g', 'DisplayName', 'Variable 2');
plot(t5b, y5b(3, :), 'b', 'DisplayName', 'Variable 3');
xlabel('Time');
ylabel('Solution Values');
title('Solution of System for 5.8c');
legend;
grid on;

% Author and ID
disp('James-Edward Gray');
disp('21015159');