clear
clc
format long

[t5a, y5a] = dp45( @f5a, [0, 1], [3/10 1/2]', 0.1, 1e-5 );


% Display the resultant values
disp("t-values: ");
disp(t5a);
disp("y-values: ");
disp(y5a);

function dy = f5a(t, y)
    % Predator-prey model
    dy = [y(1) - y(1) * y(2);  
          -y(2) + y(1) * y(2)]; 
end

% James-Edward Gray
% 21015159