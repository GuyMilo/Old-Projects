function [t_out, y_out] = dp45(f, t_rng, y0, h, eps_abs)
% Documentation explaining the function, parameters, and outputs
% 
% The Dromand Prince Method:
%
% The Dormand-Prince method is an adaptive-step method, adjusting the step 
% size dynamically based on the estimated error.
%
% The function should take five parameters:
%
% f: The function handle representing the ODEs.
% t_rng: The range [t0, tfinal] of integration.
% y0: The initial condition as a column vector.
% h: The initial step size.
% eps_abs: The absolute tolerance for error.
% The outputs should include:
%
% t_out: A vector of time values.
% y_out: A matrix of solution values corresponding to the time steps.
   
% Check for input validity

% 1. Check the range of integration (t_rng)
if ~isvector(t_rng) || length(t_rng) ~= 2 || t_rng(1) >= t_rng(2)
    error('t_rng must be a 1x2 vector with t_rng(1) < t_rng(2).');
end

% 2. Ensure y0 is a column vector
[~, cols] = size(y0);
if cols ~= 1
    error('y0 must be a column vector.');
end

% 3. Ensure that h, the step size, is a positive scalar
if h <= 0 || ~isscalar(h)
    error('h must be a positive scalar.');
end

% 4. Ensure that eps_abs, the tolerance, is a positive scalar
if eps_abs <= 0 || ~isscalar(eps_abs)
    error('eps_abs must be a positive scalar.');
end

% 5. Verify that f is a valid function handle
if ~isa(f, 'function_handle')
    error('Please make sure f is a function handle.');
end

% Initialize constants for Dormand-Prince method
A = [0          0         0        0         0        0   0;
     1          0         0        0         0        0   0;
    1/4        3/4        0        0         0        0   0;
   11/9      -14/3      40/9       0         0        0   0;
 4843/1458 -3170/243  8056/729  -53/162      0        0   0;
 9017/3168  -355/33  46732/5247  49/176 -5103/18656   0   0;
   35/384       0      500/1113 125/192 -2187/6784  11/84 0]';

b_y = [5179/57600 0 7571/16695 393/640 -92097/339200 187/2100 1/40]';
b_z = [35/384   0  500/1113  125/192  -2187/6784    11/84    0]';
c = [0 1/5 3/10 4/5 8/9 1 1]';

% Initialize output variables
t_out = t_rng(1);
% Preallocation for y_out for efficeincy
y_out = zeros(length(y0), length(t_rng)); % Estimate of max steps
y_out(:,1) = y0; % Initial condition
k = 1; % Counter for steps
K(:,1) = f(t_out,y_out(:,1)); %initialized 1st K value

% Main integration loop
while t_out(k) < t_rng(2)
    % Calculate slopes (K values)
    for m = 1:7
        if m == 1
            % First stage: no previous K values, no weighted sum
            t_inter = t_out(k);
            y_inter = y_out(:,k);
        else % For stages m = 2 to 7    
            t_inter = t_out(k) + c(m)*h;
            wted_sum = K(:,1:m-1)*A(m,1:m-1)';
            y_inter = y_out(:,k) + h*wted_sum;
        end
        % Compute the current K value
        K(:,m) = f(t_inter,y_inter);
    end
    y = y_out(:,k);
    % Compute solution estimates (y_temp, z_temp)
    y_temp = y + h*(K*b_y); 
    z_temp = y + h*(K*b_z);
    % Compute error and scaling factor (s)
    error = norm(y_temp - z_temp);
    % just in case of no error, add a precondition if there's no error
    if error == 0 
        s = 2; %Maximum scaling factor if no error
    else 
        s = (eps_abs/error)^(1/4);
    end
    % Now to adjust the step size, h, based on the scaling factor, s
    if s >= 2
        h = h*2; % error is very small, so we can safely double h
        % is still acceptable so update the time and solution        
    elseif s < 1
        h = h/2; % teh error is too large, thus hald the step size and retry again
        continue; % Skip the rest of this iteration and retry
    end
    % Update time and solution for successful step
    t_out(k+1) = t_out(k) + h; % This updates time 
    y_out(:,k+1) = y_temp; % This updates the solution
    k = k + 1; % Move to the next step 

    % Check for final step size (h) and update solution
    if t_out(k) + h > t_rng(2)
        % Adjust h to precisely reach t_rng(2), and esure h does not grow excessively large
        h = min(h, t_rng(2) - t_out(k)); 
    end
    
end
end
% James-Edward Gray
% 21015159