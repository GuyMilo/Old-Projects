clear
clc

% Initial setup
tolerance = 0.001; % Target norm difference
tf = 6.8; % Initial guess for the period
norm_diff = inf; % Initialize norm difference to a large value
max_tf = 10; % Maximum allowable value for tf to prevent infinite loops

% Iteratively adjust tf
while norm_diff >= tolerance
    % Solve the ODE using dp45
    [t5a, y5a] = dp45(@f5a, [0, tf], [3/10; 1/2], 0.001, 1e-10);
    
    % Compute the norm difference between initial and final points
    norm_diff = norm(y5a(:, end) - y5a(:, 1));
    
    % Display the current tf and norm difference
    disp(['tf = ', num2str(tf), ', norm difference = ', num2str(norm_diff)]);
    
    % Adjust tf based on the norm difference
    if norm_diff > tolerance
        tf = tf + 0.01; % Fine-tune the increment
    end
    
    % Check if tf exceeds the maximum limit
    if tf > max_tf
        disp('Failed to converge within the maximum tf limit.');
        break;
    end
end

% Plot the phase portrait of the predator-prey dynamics
plot(y5a(1, :), y5a(2, :), 'b', 'LineWidth', 1.5);
xlabel('Prey Population');
ylabel('Predator Population');
title(['Predator-Prey Dynamics, Period = ', num2str(tf)]);
grid on;

% Add descriptive labels to the plot
legend('Predator-Prey Trajectory', 'Location', 'Best');
hold off;

% Author and ID
disp('James-Edward Gray');
disp('21015159');