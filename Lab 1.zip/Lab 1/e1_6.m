clear
clc

% Set the format to hex to observe the floating-point number representation
format hex;

% Find the next smaller floating-point number before 1
smaller_than_one = (1 - eps(1)/2);

% Display the result
fprintf('The next smallest floating-point number before 1 is: %.17f \n', smaller_than_one);


% Display the hexadecimal representation of the result
disp('Hexadecimal representation:');
disp(num2hex(smaller_than_one));

% eps(1)/2: This reduces the size of eps by half to make a very small decrement from 1. 
% This ensures you're finding the next number below 1 without skipping too far (as 1 - eps would skip multiple smaller numbers).

% num2hex(smaller_than_one): This displays the hexadecimal representation of the number 
% so you can see how the floating-point number is stored in memory.

%James-Edward Gray
%21015159