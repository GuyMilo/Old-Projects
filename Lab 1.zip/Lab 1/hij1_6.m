clear
clc

find_powers_of_10();

function find_powers_of_10()
    % Set format to hex to observe floating-point representations
    format hex;

    % 1.6h: Smallest n where 10^n is not denormalized
    n = -400;  % Start with a very small value for n
    while is_denormalized(10^n)
        n = n + 1;  % Increment n until 10^n is no longer denormalized
    end
    fprintf('1.6h: Smallest n such that 10^n is not denormalized: %d\n', n);
    
    % 1.6i: Smallest n where 10^n is not zero
    n = -400;  % Start with a very small value for n
    while 10^n == 0
        n = n + 1;  % Increment n until 10^n is no longer zero
    end
    fprintf('1.6i: Smallest n such that 10^n is not zero: %d\n', n);
    
    % 1.6j: Largest n where 10^n is not infinity
    n = 400;  % Start with a very large value for n
    while ~isinf(10^n)
        n = n + 1;  % Increment n until 10^n becomes infinity
    end
    fprintf('1.6j: Largest n such that 10^n is not infinity: %d\n', n-1);  % n-1 is the last valid n before infinity
end

function result = is_denormalized(value)
    % Check if a number is denormalized in IEEE 754 format
    % Denormalized numbers have an exponent of zero, but are not exactly zero
    hex_val = num2hex(value);
    exponent_bits = hex_val(2:4);  % Extract the exponent part from the hex value
    result = strcmp(exponent_bits, '000');  % Denormalized if exponent is all zeros
end

%James-Edward Gray
%21015159