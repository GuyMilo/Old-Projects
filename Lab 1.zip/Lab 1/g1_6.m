clear
clc

% Define the hexadecimal representations to process
hex_values = ["3f193a0000000000", "4020f10000000000", "4033f00000000000", ...
              "414e600000000000", "3f74300000000000"];

% Display header
fprintf('%-20s %-34s\n', 'Hexadecimal', 'Mantissa (with implicit 1)');
fprintf('%-20s %-34s\n', '-----------', '-----------------------------');


% Call the function
mantissas = extractMantissas(hex_values);

function mantissa_bits = extractMantissas(hex_values)
    % Loop through each hex value
    for i = 1:length(hex_values)
        % Convert hex to double using hex2num
        num = hex2num(hex_values{i});    
       
        % Convert the number to its IEEE 754 binary representation
        binary_rep = dec2bin(typecast(num, 'uint64'), 64);

        % Extract the mantissa bits (bits 13 to 64)
        mantissa_bits = binary_rep(13:end); 

        % Display the hexadecimal and mantissa
        fprintf('%-20s 1.%-32s\n', hex_values{i}, mantissa_bits);  
    end
end

%Jmaes-Edward Gray
%21015159