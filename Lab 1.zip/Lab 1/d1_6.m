clear
clc

% Define the hexadecimal representations
hex_values = {'4020f5ff5675cf94', '4033f307fea5b029', '408e6a8a831e7905',... 
              '3f743e05659feaf3', '3f84be1ee8f9f90c', '3ef0f5ff5675cf94'};

% Bias for double-precision (IEEE 754)
bias = 1023;

% Loop through each hex value
for i = 1:length(hex_values)
    % Convert hex to binary using typecast to get 64-bit binary representation
    num = hex2num(hex_values{i});
    
    % Convert the number to its IEEE 754 binary representation
    binary_rep = dec2bin(typecast(num, 'uint64'), 64);
    
    % Extract the exponent bits (bits 2 to 12 in IEEE 754)
    exponent_bits = binary_rep(2:12);
    
    % Convert exponent bits from binary to decimal
    exponent = bin2dec(exponent_bits);
    
    % Subtract the bias to get the actual exponent
    actual_exponent = exponent - bias;
    
    % Display the exponent for the corresponding hex value
    disp(['Hex value ', hex_values{i}, ' has an exponent of ', num2str(actual_exponent)]);
end


%James-EDward Gray
%21015159