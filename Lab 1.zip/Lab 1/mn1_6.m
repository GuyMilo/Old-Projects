clear
clc

% Define the hexadecimal floating-point numbers for Table 4
hex_values_4 = {'1ec08f8bf99a36fe', '67caccf63d443628', '691b6cf1ba816f22', ...
                '46b6acf2673e096a', '183dc6edceef302d'};

% Call the function to sort the hex values
sorted_values_4 = sortHexFloatNumbers(hex_values_4);

% Display the sorted values
disp('Sorted values for Table 4:');
disp(sorted_values_4);

% Define the hexadecimal floating-point numbers for Table 5
hex_values_5 = {'cd617c809c482961', '54d3c359e37c5187', '44d1c843f64a8c8e', ...
                'bb825a24626f4112', 'c42c3c937cc00418', '2d91ca5f2651c8b8'};

% Call the function to sort the hex values
sorted_values_5 = sortHexFloatNumbers(hex_values_5);

% Display the sorted values
disp('Sorted values for Table 5:');
disp(sorted_values_5);

function sorted_numbers = sortHexFloatNumbers(hex_values)
    % Converts an array of hex values to floating point, sorts them, and returns sorted values.
    
    % Convert the hex values to double-precision floating point numbers
    float_values = zeros(size(hex_values)); % Preallocate array for float numbers
    for i = 1:length(hex_values)
        float_values(i) = hex2num(hex_values{i});
    end
    
    % Sort the floating-point numbers
    [sorted_float_values, sort_idx] = sort(float_values);
    
    % Convert sorted floating-point values back to hex representation
    sorted_numbers = strings(size(hex_values)); % Preallocate array for sorted hex values
    for i = 1:length(sorted_float_values)
        sorted_numbers(i) = num2hex(sorted_float_values(i));
    end
end


%james-Edward Gray
%21015159