clear
clc

actual_value = 2.604215099096980;
n_values = [11,21,41,81, 161, 321,641];

for k = 1:length(n_values)
    n = n_values(k);
    [t_out, y_out] = euler(@f3c, [0 1], 1, n);
    approx = y_out(end);
    abs_error = abs(approx - actual_value);

    fprintf('n = %d, Approximation = %.15f, Absolute Error = %.15f\n', n, approx, abs_error);
end

%James-Edward Gray
%21015159
%jemgray