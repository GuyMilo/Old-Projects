clear
clc
% Define parameters
t_rng = [0, 1];
y0 = 1;
n = 11;

% Call the Heun function
[t_out, y_out] = heun(@f3c, t_rng, y0, n);

% Print the results
disp('Time values (t_out):');
disp(t_out);
disp('Approximated y values (y_out):');
disp(y_out);

%James-Edward Gray
%21015159
%jemgray