% Heun's method
%
% We aim to approximate a solution to a first-order initial-value problem (IVP) using 
% Huen's method. This involves iteratively estimating the next value of the solution 
% using the slope at the current point.  This aims to fix euler's
% approximation error.
%
% Parameters
% ==========
%    f: A function handle representing the bivariate function f(t, y)
%    t_rng: The row vector of two values [t0, tfinal]
%    y0: The initial condition y(t0)
%    n: Number of points dividing the interval [t0, tfinal]
% 
% Return Values
% =============
%    t_out: A row vector of n equally spaced values from t0 to tfinal
%    y_out: A row vector of n values where y_out(1) equals y0 and y_out(k) approximates 
%           y(t) at t_out(k) from 2 to n

function [t_out, y_out] = heun(f, t_rng, y0, n)
    % Argument Checking

    % Check if f is a function handle
    if ~isa(f, 'function_handle')
        error('MATLAB:invalid_argument', 'The argument f is not a function handle.');
    end

    % Check if t_rng is a 1x2 row vector
    if ~isequal(size(t_rng), [1, 2])
        error('MATLAB:invalid_argument', 'The argument t_rng is not a row vector with two entries.');
    end

    % Check if y0 is a scalar
    if ~isscalar(y0)
        error('MATLAB:invalid_argument', 'The argument y0 is not a scalar.');
    end

    % Check if n is a positive integer
    if ~isscalar(n) || n <= 0 || n ~= round(n)
        error('MATLAB:invalid_argument', 'The argument n is not a positive integer.');
    end

    % Extract and initialize the t0 and tfinal parameters
    t0 = t_rng(1);
    tfinal = t_rng(2);

    % Calculate the step size, h
    h = (tfinal - t0) / (n - 1);

    % Preallocate t_out and y_out vectors
    t_out = linspace(t0, tfinal, n);
    y_out = zeros(1, n);
    y_out(1) = y0;  % Set the initial condition

    % Loop to compute the y_out approximation
    for k = 1:n-1
        % Calculate the slope at the current point
        K1 = f(t_out(k), y_out(k));
        
        % Predict the next value using K1
        y_predict = y_out(k) + h * K1;
        
        % Calculate the slope at the predicted point (K2)
        K2 = f(t_out(k+1), y_predict);
        
        % Update the next value using Heun's formula
        y_out(k + 1) = y_out(k) + h * (K1 + K2) / 2;
    end
end
%James-Edward Gray
%21015159
%jemgray
