[t3a, y3a] = heun( @f3a, [0, 1], 0, 11 );
plot( t3a, y3a, 'or' )
hold on
[t3a, y3a] = ode45( @f3a, [0, 1], 0 );
plot( t3a, y3a, 'b' )
